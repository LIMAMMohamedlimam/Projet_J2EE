package com.projetjee.GestionDeScolarite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeScolariteApplicationTests {

	@Test
	void contextLoads() {
	}

}
