package com.projetjee.GestionDeScolarite.controller;

import com.projetjee.GestionDeScolarite.entity.Matiere;
import com.projetjee.GestionDeScolarite.service.MatiereService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MatiereController {

    private final MatiereService matiereService;

    public MatiereController(MatiereService matiereService) {
        this.matiereService = matiereService;
    }

    @GetMapping("/matieres")
    public String getAllMatieres(Model model) {
        List<Matiere> matieres = matiereService.getAllMatieres();
        model.addAttribute("matieres", matieres);
        return "admin/matieres";
    }
}
