package com.projetjee.GestionDeScolarite.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Entity
@DiscriminatorValue("ETUDIANT")
public class Etudiant extends Utilisateur {

    @OneToMany(mappedBy = "etudiant", cascade = CascadeType.ALL)
    private List<Evaluation> evaluations = new ArrayList<>(); // Liste des évaluations passées par l'étudiant

    @Transient
    private double resultat; // Résultat de l'étudiant (moyenne pondérée)

    // Constructeur
    public Etudiant(int id, String nom, String prenom, Date dateDeNaissance, String email, String contact, String motDePasse) {
        super(id, nom, prenom, dateDeNaissance, email, contact, motDePasse);
    }

    // Getters et Setters
    public List<Evaluation> getEvaluations() {
        return evaluations;
    }

    public void setEvaluations(List<Evaluation> evaluations) {
        this.evaluations = evaluations;
        calculerResultat();  // Recalculer le résultat à chaque mise à jour des évaluations
    }

    public double getResultat() {
        return resultat;
    }

    // Méthode pour calculer le résultat (moyenne pondérée)
    public void calculerResultat() {
        double total = 0;
        double sommeCoefficient = 0;
        for (Evaluation evaluation : evaluations) {
            total += evaluation.getNote() * evaluation.getMatiere().getCoefficient(); // Pondération par le coefficient de la matière
            sommeCoefficient += evaluation.getMatiere().getCoefficient();
        }
        this.resultat = sommeCoefficient != 0 ? total / sommeCoefficient : 0;
    }
}


