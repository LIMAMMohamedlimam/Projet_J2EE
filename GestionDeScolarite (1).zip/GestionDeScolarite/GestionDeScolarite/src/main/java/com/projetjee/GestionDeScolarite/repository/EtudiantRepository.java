package com.projetjee.GestionDeScolarite.repository;

import com.projetjee.GestionDeScolarite.entity.Etudiant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EtudiantRepository extends JpaRepository<Etudiant, Integer> {
    List<Etudiant> findByNomContaining(String keyword); // Recherche par mot-clé
}



