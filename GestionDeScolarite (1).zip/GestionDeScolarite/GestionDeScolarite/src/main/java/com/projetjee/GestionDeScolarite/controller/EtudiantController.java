package com.projetjee.GestionDeScolarite.controller;

import com.projetjee.GestionDeScolarite.entity.Etudiant;
import com.projetjee.GestionDeScolarite.service.EtudiantService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class EtudiantController {

    private final EtudiantService etudiantService;

    public EtudiantController(EtudiantService etudiantService) {
        this.etudiantService = etudiantService;
    }

    @GetMapping("/etudiants/home")
    public String showEtudiantHome(Model model) {
        List<Etudiant> etudiants = etudiantService.getAllEtudiants();
        model.addAttribute("etudiants", etudiants);
        return "etudiants/home";
    }

    @GetMapping("/etudiants/search")
    public String searchEtudiants(@RequestParam String keyword, Model model) {
        List<Etudiant> results = etudiantService.searchEtudiants(keyword);
        model.addAttribute("etudiants", results);
        return "etudiants/home";
    }
}

