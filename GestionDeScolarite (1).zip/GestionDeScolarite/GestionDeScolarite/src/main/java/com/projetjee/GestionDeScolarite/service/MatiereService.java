package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Matiere;
import com.projetjee.GestionDeScolarite.repository.MatiereRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MatiereService {

    private final MatiereRepository matiereRepository;

    public MatiereService(MatiereRepository matiereRepository) {
        this.matiereRepository = matiereRepository;
    }

    public List<Matiere> getAllMatieres() {
        return matiereRepository.findAll();
    }
}
