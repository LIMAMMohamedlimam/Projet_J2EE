package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Enseignant;
import com.projetjee.GestionDeScolarite.repository.EnseignantRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnseignantService {

    private final EnseignantRepository enseignantRepository;

    public EnseignantService(EnseignantRepository enseignantRepository) {
        this.enseignantRepository = enseignantRepository;
    }

    public List<Enseignant> getAllEnseignants() {
        return enseignantRepository.findAll();
    }

    public Enseignant getEnseignantById(int id) {
        return enseignantRepository.findById(id).orElse(null);
    }
}

