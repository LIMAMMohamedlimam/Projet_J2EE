package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Utilisateur;
import com.projetjee.GestionDeScolarite.repository.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LoginService {

    private final UtilisateurRepository utilisateurRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public LoginService(UtilisateurRepository utilisateurRepository, PasswordEncoder passwordEncoder) {
        this.utilisateurRepository = utilisateurRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Authentifier un utilisateur en fonction de son email et de son mot de passe.
     */
    public Optional<Utilisateur> authenticate(String email, String password) {
        Optional<Utilisateur> utilisateur = Optional.ofNullable(utilisateurRepository.findByEmail(email));
        if (utilisateur.isPresent() && passwordEncoder.matches(password, utilisateur.get().getMotDePasse())) {
            return utilisateur;
        }
        return Optional.empty();
    }

    /**
     * Inscrire un nouvel utilisateur (avec cryptage du mot de passe).
     */
    public Utilisateur register(Utilisateur utilisateur) {
        utilisateur.setMotDePasse(passwordEncoder.encode(utilisateur.getMotDePasse()));
        return utilisateurRepository.save(utilisateur);
    }
}

