package com.projetjee.GestionDeScolarite.entity;

import jakarta.persistence.*;

@Entity
public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "etudiant_id", nullable = false)
    private Etudiant etudiant;  // L'étudiant qui a passé l'évaluation

    @ManyToOne
    @JoinColumn(name = "matiere_id", nullable = false)
    private Matiere matiere;    // La matière dans laquelle l'évaluation a eu lieu

    @Column(nullable = false)
    private double note; // La note de l'étudiant pour cette évaluation

    // Constructeur
    public Evaluation(Etudiant etudiant, Matiere matiere, double note) {
        this.etudiant = etudiant;
        this.matiere = matiere;
        this.note = note;
    }

    // Getters et Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Etudiant getEtudiant() {
        return etudiant;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    public double getNote() {
        return note;
    }

    public void setNote(double note) {
        this.note = note;
    }
}
