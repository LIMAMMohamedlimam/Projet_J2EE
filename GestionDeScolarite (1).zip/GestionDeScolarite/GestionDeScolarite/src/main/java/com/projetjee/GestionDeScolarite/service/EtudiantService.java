package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Etudiant;
import com.projetjee.GestionDeScolarite.repository.EtudiantRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EtudiantService {

    private final EtudiantRepository etudiantRepository;

    public EtudiantService(EtudiantRepository etudiantRepository) {
        this.etudiantRepository = etudiantRepository;
    }

    public List<Etudiant> getAllEtudiants() {
        return etudiantRepository.findAll();
    }

    public Etudiant getEtudiantById(int id) {
        return etudiantRepository.findById(id).orElse(null);
    }

    public List<Etudiant> searchEtudiants(String keyword) {
        return etudiantRepository.findByNomContaining(keyword);
    }
}
