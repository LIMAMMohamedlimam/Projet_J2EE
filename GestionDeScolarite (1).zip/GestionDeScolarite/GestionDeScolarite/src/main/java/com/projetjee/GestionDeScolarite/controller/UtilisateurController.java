package com.projetjee.GestionDeScolarite.controller;

import com.projetjee.GestionDeScolarite.entity.Utilisateur;
import com.projetjee.GestionDeScolarite.service.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/utilisateurs")
public class UtilisateurController {

    @Autowired
    private UtilisateurService utilisateurService;

    // Créer ou mettre à jour un utilisateur
    @PostMapping
    public Utilisateur saveUtilisateur(@RequestBody Utilisateur utilisateur) {
        return utilisateurService.saveUtilisateur(utilisateur);
    }

    // Obtenir un utilisateur par son ID
    @GetMapping("/{id}")
    public Optional<Utilisateur> getUtilisateurById(@PathVariable int id) {
        return utilisateurService.findUtilisateurById(id);
    }

    // Obtenir un utilisateur par son email
    @GetMapping("/email/{email}")
    public Utilisateur getUtilisateurByEmail(@PathVariable String email) {
        return utilisateurService.findUtilisateurByEmail(email);
    }

    // Obtenir un utilisateur par son contact
    @GetMapping("/contact/{contact}")
    public Utilisateur getUtilisateurByContact(@PathVariable String contact) {
        return utilisateurService.findUtilisateurByContact(contact);
    }

    // Supprimer un utilisateur
    @DeleteMapping("/{id}")
    public void deleteUtilisateur(@PathVariable int id) {
        utilisateurService.deleteUtilisateur(id);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam String email, @RequestParam String motDePasse) {
        Utilisateur utilisateur = utilisateurService.findUtilisateurByEmail(email);
        if (utilisateur != null && utilisateur.getMotDePasse().equals(motDePasse)) {
            return ResponseEntity.ok("Connexion réussie !");
        } else {
            return ResponseEntity.status(401).body("Identifiants incorrects !");
        }
    }
}

