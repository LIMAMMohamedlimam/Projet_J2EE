package com.projetjee.GestionDeScolarite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String showLoginPage(@RequestParam(required = false) String role, Model model) {
        model.addAttribute("role", role);
        return "auth/login";
    }

    @PostMapping("/authenticate")
    public String authenticateUser(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String role,
            Model model
    ) {
        // Simulation de l'authentification (remplacer par une vraie logique si nécessaire)
        if ("admin".equals(username) && "admin".equals(password)) {
            return "redirect:/admin/home";
        } else if ("enseignant".equals(username) && "enseignant".equals(password)) {
            return "redirect:/enseignants/home";
        } else if ("etudiant".equals(username) && "etudiant".equals(password)) {
            return "redirect:/etudiants/home";
        } else {
            model.addAttribute("error", "Nom d'utilisateur ou mot de passe incorrect !");
            return "auth/login";
        }
    }
}
