package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Cours;
import com.projetjee.GestionDeScolarite.repository.CoursRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CoursService {

    private final CoursRepository coursRepository;

    public CoursService(CoursRepository coursRepository) {
        this.coursRepository = coursRepository;
    }

    public List<Cours> getAllCourses() {
        return coursRepository.findAll();
    }

    public List<Cours> getCoursesByEnseignant(int enseignantId) {
        return coursRepository.findByEnseignant_Id(enseignantId);
    }

    public Cours getCourseById(int id) {
        return coursRepository.findById(id).orElse(null);
    }
}
