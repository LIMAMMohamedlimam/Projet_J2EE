package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Utilisateur;
import com.projetjee.GestionDeScolarite.repository.UtilisateurRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UtilisateurService {

    @Autowired
    private UtilisateurRepository utilisateurRepository;

    // Création ou mise à jour d'un utilisateur
    public Utilisateur saveUtilisateur(Utilisateur utilisateur) {
        return utilisateurRepository.save(utilisateur);
    }

    // Recherche d'un utilisateur par son ID
    public Optional<Utilisateur> findUtilisateurById(int id) {
        return utilisateurRepository.findById(id);
    }

    // Recherche d'un utilisateur par son email
    public Utilisateur findUtilisateurByEmail(String email) {
        return utilisateurRepository.findByEmail(email);
    }

    // Recherche d'un utilisateur par son contact
    public Utilisateur findUtilisateurByContact(String contact) {
        return utilisateurRepository.findByContact(contact);
    }

    // Suppression d'un utilisateur par son ID
    public void deleteUtilisateur(int id) {
        utilisateurRepository.deleteById(id);
    }
}

