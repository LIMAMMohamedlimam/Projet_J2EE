package com.projetjee.GestionDeScolarite.controller;

import com.projetjee.GestionDeScolarite.entity.Inscription;
import com.projetjee.GestionDeScolarite.service.InscriptionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class InscriptionController {

    private final InscriptionService inscriptionService;

    public InscriptionController(InscriptionService inscriptionService) {
        this.inscriptionService = inscriptionService;
    }

    @GetMapping("/inscriptions")
    public String getAllInscriptions(Model model) {
        List<Inscription> inscriptions = inscriptionService.getAllInscriptions();
        model.addAttribute("inscriptions", inscriptions);
        return "admin/inscriptions";
    }
}
