package com.projetjee.GestionDeScolarite.entity;

import jakarta.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "Inscription")
public class Inscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idInscription;

    @ManyToOne
    @JoinColumn(name = "idEtudiant", nullable = false)
    private Etudiant etudiant;

    @ManyToOne
    @JoinColumn(name = "idCours", nullable = false)
    private Cours cours;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date dateInscription;

    public Inscription(int idInscription, Etudiant etudiant, Cours cours, Date dateInscription) {
        this.idInscription = idInscription;
        this.etudiant = etudiant;
        this.cours = cours;
        this.dateInscription = dateInscription;
    }

    public int getIdInscription() {
        return idInscription;
    }

    public void setIdInscription(int idInscription) {
        this.idInscription = idInscription;
    }

    public Etudiant getEtudiant() {
        return etudiant;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    public Cours getCours() {
        return cours;
    }

    public void setCours(Cours cours) {
        this.cours = cours;
    }

    public Date getDateInscription() {
        return dateInscription;
    }

    public void setDateInscription(Date dateInscription) {
        this.dateInscription = dateInscription;
    }

    @Override
    public String toString() {
        return "Inscription{" +
                "idInscription=" + idInscription +
                ", etudiant=" + etudiant +
                ", cours=" + cours +
                ", dateInscription=" + dateInscription +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Inscription that)) return false;
        return getIdInscription() == that.getIdInscription() && Objects.equals(getEtudiant(), that.getEtudiant()) && Objects.equals(getCours(), that.getCours()) && Objects.equals(getDateInscription(), that.getDateInscription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdInscription(), getEtudiant(), getCours(), getDateInscription());
    }

    public Inscription() {
        super();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
