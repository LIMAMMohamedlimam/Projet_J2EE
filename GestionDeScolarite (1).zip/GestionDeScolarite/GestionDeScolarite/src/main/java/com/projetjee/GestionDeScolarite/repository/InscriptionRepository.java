package com.projetjee.GestionDeScolarite.repository;

import com.projetjee.GestionDeScolarite.entity.Inscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InscriptionRepository extends JpaRepository<Inscription, Integer> {
    // Trouvez toutes les inscriptions pour un étudiant
    List<Inscription> findByEtudiant_Id(int etudiantId);
}
