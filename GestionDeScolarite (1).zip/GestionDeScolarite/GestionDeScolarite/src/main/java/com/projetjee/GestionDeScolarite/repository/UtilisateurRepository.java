package com.projetjee.GestionDeScolarite.repository;

import com.projetjee.GestionDeScolarite.entity.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UtilisateurRepository extends JpaRepository<Utilisateur, Integer> {

    // Recherche un utilisateur par son email
    Utilisateur findByEmail(String email);

    // Recherche un utilisateur par son contact
    Utilisateur findByContact(String contact);
}
