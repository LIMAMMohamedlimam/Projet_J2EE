package com.projetjee.GestionDeScolarite.controller;

import com.projetjee.GestionDeScolarite.entity.Cours;
import com.projetjee.GestionDeScolarite.service.CoursService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class CoursController {

    private final CoursService coursService;

    public CoursController(CoursService coursService) {
        this.coursService = coursService;
    }

    @GetMapping("/cours")
    public String getAllCourses(Model model) {
        List<Cours> coursList = coursService.getAllCourses();
        model.addAttribute("cours", coursList);
        return "admin/cours";
    }
}



