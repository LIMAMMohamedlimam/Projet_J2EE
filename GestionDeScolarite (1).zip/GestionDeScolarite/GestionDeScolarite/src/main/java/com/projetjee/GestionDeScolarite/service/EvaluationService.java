package com.projetjee.GestionDeScolarite.service;

import com.projetjee.GestionDeScolarite.entity.Evaluation;
import com.projetjee.GestionDeScolarite.repository.EvaluationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EvaluationService {

    private final EvaluationRepository evaluationRepository;

    public EvaluationService(EvaluationRepository evaluationRepository) {
        this.evaluationRepository = evaluationRepository;
    }

    public List<Evaluation> getEvaluationsByEtudiant(int etudiantId) {
        return evaluationRepository.findByEtudiant_Id(etudiantId);
    }

    public List<Evaluation> getAllEvaluations() {
        return evaluationRepository.findAll();
    }
}

