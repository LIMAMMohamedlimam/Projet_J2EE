package com.projetjee.GestionDeScolarite.entity;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "Groupe")
public class Groupe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idGroupe;

    @Column(nullable = false, length = 50)
    private String nom;

    public Groupe(int idGroupe, String nom) {
        this.idGroupe = idGroupe;
        this.nom = nom;
    }

    public int getIdGroupe() {
        return idGroupe;
    }

    public void setIdGroupe(int idGroupe) {
        this.idGroupe = idGroupe;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public String toString() {
        return "Groupe{" +
                "idGroupe=" + idGroupe +
                ", nom='" + nom + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Groupe groupe)) return false;
        return getIdGroupe() == groupe.getIdGroupe() && Objects.equals(getNom(), groupe.getNom());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdGroupe(), getNom());
    }

    public Groupe() {
        super();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
