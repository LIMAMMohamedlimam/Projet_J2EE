package com.projetjee.GestionDeScolarite.entity;

import jakarta.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "Cours")
public class Cours {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idCours;

    @Temporal(TemporalType.DATE)
    private Date date;

    @ManyToOne
    @JoinColumn(name = "idMatiere", nullable = false)
    private Matiere matiere;

    @ManyToOne
    @JoinColumn(name = "idEnseignant", nullable = false)
    private Enseignant enseignant;

    public Cours(int idCours, Date date, Matiere matiere, Enseignant enseignant) {
        this.idCours = idCours;
        this.date = date;
        this.matiere = matiere;
        this.enseignant = enseignant;
    }

    public int getIdCours() {
        return idCours;
    }

    public void setIdCours(int idCours) {
        this.idCours = idCours;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    public Enseignant getEnseignant() {
        return enseignant;
    }

    public void setEnseignant(Enseignant enseignant) {
        this.enseignant = enseignant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Cours cours)) return false;
        return getIdCours() == cours.getIdCours() && Objects.equals(getDate(), cours.getDate()) && Objects.equals(getMatiere(), cours.getMatiere()) && Objects.equals(getEnseignant(), cours.getEnseignant());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdCours(), getDate(), getMatiere(), getEnseignant());
    }

    public Cours() {
        super();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
