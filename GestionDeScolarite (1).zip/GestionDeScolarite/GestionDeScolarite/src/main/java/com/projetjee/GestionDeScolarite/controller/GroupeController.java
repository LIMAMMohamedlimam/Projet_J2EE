package com.projetjee.GestionDeScolarite.controller;

import com.projetjee.GestionDeScolarite.entity.Groupe;
import com.projetjee.GestionDeScolarite.service.GroupeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class GroupeController {

    private final GroupeService groupeService;

    public GroupeController(GroupeService groupeService) {
        this.groupeService = groupeService;
    }

    @GetMapping("/groupes")
    public String getAllGroups(Model model) {
        List<Groupe> groupes = groupeService.getAllGroups();
        model.addAttribute("groupes", groupes);
        return "enseignants/groupes";
    }
}
