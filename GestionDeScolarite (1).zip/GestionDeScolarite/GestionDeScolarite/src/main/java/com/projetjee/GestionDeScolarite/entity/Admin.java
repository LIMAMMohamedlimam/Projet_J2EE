package com.projetjee.GestionDeScolarite.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@DiscriminatorValue("ADMIN")
public class Admin extends Utilisateur {
    public Admin(int id, String nom, String prenom, Date dateDeNaissance, String email, String contact, String motDePasse) {
        super(id, nom, prenom, dateDeNaissance, email, contact, motDePasse);
    }
    // Ajoutez des champs spécifiques à l'administrateur si nécessaire
}

